"""koeken - Linear Discriminant Analysis (LEfSe) on A Longitudinal Microbial Dataset."""

__version__ = '0.2.0'
__author__ = 'Thomas W. Battaglia <tb1280@nyu.edu>'
__all__ = []
