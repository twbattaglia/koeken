"""koeken - Linear Discriminant Analysis (LEfSe) on A Longitudinal Microbial Dataset."""

__author__ = 'Thomas W. Battaglia'
__copyright__ = 'Copyright 2015'
__license__ = 'BSD'
__version__ = '0.2.0-dev'
__email__ = 'tb1280@nyu.edu'
__status__ = 'Development'
__all__ = []
